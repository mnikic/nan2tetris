
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.function.Function;

import static java.util.Arrays.asList;

public class CompilationEngine implements AutoCloseable {
    private static final Map<Character, String> ESCAPE_CHARS = new HashMap<Character, String>() {{
        put('<', "&lt;");
        put('>', "&gt;");
        put('"', "&quot;");
        put('&', "&amp;");
    }};
    private static final Set<KeyWordType> KEY_WORD_CONSTANT = new HashSet<>(asList(KeyWordType.TRUE, KeyWordType.FALSE, KeyWordType.NULL, KeyWordType.THIS));
    private static final List<Character> UNARY_OPS = asList('~', '-');
    private static final List<Character> TERM_LOOKAHEAD = asList('[', '.', '(');
    private final BufferedWriter writer;
    private final JackTokenizer tokenizer;

    public CompilationEngine(JackTokenizer tokenizer, Path file) {
        try {
            if (Files.exists(file)) {
                Files.delete(file);
            }
            this.writer = Files.newBufferedWriter(Files.createFile(file));
            this.tokenizer = tokenizer;
        } catch (IOException e) {
            throw new IllegalArgumentException("Something is up with the file!");
        }
    }

    //type, className, subroutineName, variableName, statement, subroutineCall don't have methods

    public void compileClass() throws IOException {
        writer.write("<class>");// no new line before
        writeOut(eatKeyWord(KeyWordType.CLASS));
        String className = eatIdentifier();
        writeOut(className);
        writeOut(eatSymbol("{"));

        while (tokenizer.hasMoreTokens()) {
            Token nextToken = tokenizer.getFutureToken();
            if (nextToken.tokenType() == TokenType.SYMBOL && nextToken.symbol() == '}') {
                Character character = eatSymbol("}");
                writeOut(character);
                writer.newLine();
                writer.write("</class>");
                return;
            }
            if (nextToken.tokenType() != TokenType.KEYWORD) {
                throw new IllegalArgumentException("Blah blah");
            }
            if (nextToken.keyWord() == KeyWordType.STATIC || nextToken.keyWord() == KeyWordType.FIELD) {
                writer.newLine();
                writer.write("<classVarDec>");
                compileClassVarDec();
                writer.newLine();
                writer.write("</classVarDec>");
            } else if (nextToken.keyWord() == KeyWordType.CONSTRUCTOR || nextToken.keyWord() == KeyWordType.FUNCTION
                    || nextToken.keyWord() == KeyWordType.METHOD) {
                writer.newLine();
                writer.write("<subroutineDec>");
                compileSubroutineDec();
                writer.newLine();
                writer.write("</subroutineDec>");
            }
        }

        if (tokenizer.hasMoreTokens()) {
            throw new IllegalArgumentException("Something is fucked! Tokens appear after the end of class");
        }
    }

    private void writeOut(KeyWordType classKeyWord) throws IOException {
        writer.newLine();
        writer.write(classKeyWord.prettyPrint());
    }

    private void writeOutIntConstant(int intConstant) throws IOException {
        writer.newLine();
        writer.write("<integerConstant> " + intConstant + " </integerConstant>");
    }

    private void writeOut(String identifier) throws IOException {
        writer.newLine();
        writer.write("<identifier> " + identifier + " </identifier>");
    }

    private void writeOut(Character symbol) throws IOException {
        writer.newLine();
        writer.write("<symbol>" + ESCAPE_CHARS.getOrDefault(symbol, "" + symbol) + "</symbol>");
    }

    private String eatIdentifier() {
        return extractNext(TokenType.IDENTIFIER, Token::identifier);
    }

    private <T> T extractNext(TokenType type, Function<Token, T> transformer) {
        if (tokenizer.hasMoreTokens()) {
            tokenizer.advance();
            Token token = tokenizer.getCurrentToken();
            if (!type.equals(token.tokenType())) {
                throw new IllegalArgumentException("Didn't get what I was hoping for. Got " + token.tokenType()
                        + " expected " + type + ". Token: " + token);
            }
            return transformer.apply(token);
        }
        return null;
    }

    private KeyWordType eatKeyWord(KeyWordType expected) {
        KeyWordType gotten = extractNext(TokenType.KEYWORD, Token::keyWord);
        if (!gotten.equals(expected)) {
            throw new IllegalArgumentException("Noooo, I expect " + expected + " at the end!!!");
        }
        return gotten;
    }

    private KeyWordType eatKeyWord(Collection<KeyWordType> expected) {
        KeyWordType gotten = extractNext(TokenType.KEYWORD, Token::keyWord);
        if (!expected.contains(gotten)) {
            throw new IllegalArgumentException("Noooo, I expect " + expected + " at the end!!!");
        }
        return gotten;
    }

    private Character eatSymbol(String expected) {
        Character gotten = extractNext(TokenType.SYMBOL, Token::symbol);
        if (!gotten.equals(expected.charAt(0))) {
            throw new IllegalArgumentException("Noooo, I expect " + expected + " at the end!!!");
        }
        return gotten;
    }

    private Character eatSymbol(List<Character> expected) {
        Character gotten = extractNext(TokenType.SYMBOL, Token::symbol);
        if (!expected.contains(gotten)) {
            throw new IllegalArgumentException("Noooo, I expect " + expected + " at the end!!!");
        }
        return gotten;
    }

    public void compileClassVarDec() throws IOException {
        tokenizer.advance();
        Token token = tokenizer.getCurrentToken();
        writeOut(token.keyWord());
        compileTypeWithoutVar();

    }

    private void compileTypeWithoutVar() throws IOException {
        //expecting type
        eatType(asList(KeyWordType.BOOLEAN, KeyWordType.INT, KeyWordType.CHAR));
        String varName = eatIdentifier();
        writeOut(varName);
        while (tokenizer.hasMoreTokens() && !(tokenizer.getFutureToken().tokenType().equals(TokenType.SYMBOL) && tokenizer.getFutureToken().symbol() == ';')) {
            Character comma = eatSymbol(",");
            writeOut(comma);
            String oneMoreVarName = eatIdentifier();
            writeOut(oneMoreVarName);
        }
        if (!tokenizer.hasMoreTokens()) {
            throw new IllegalArgumentException("Noooo, I expect ; at the end!!!");
        }
        writeOut(eatSymbol(";"));
    }

    private void eatType(List<KeyWordType> types) throws IOException {
        if (TokenType.IDENTIFIER.equals(tokenizer.getFutureToken().tokenType())) {
            String type = eatIdentifier();
            writeOut(type);
        } else {
            KeyWordType keyWordType = eatKeyWord(types);
            writeOut(keyWordType);
        }
    }

    public void compileSubroutineDec() throws IOException {
        KeyWordType subroutine = eatKeyWord(asList(KeyWordType.CONSTRUCTOR, KeyWordType.FUNCTION, KeyWordType.METHOD));
        writeOut(subroutine);
        eatType(asList(KeyWordType.VOID, KeyWordType.BOOLEAN, KeyWordType.INT, KeyWordType.CHAR));
        String soubroutineName = eatIdentifier();
        writeOut(soubroutineName);
        writeOut(eatSymbol("("));
        writer.newLine();
        writer.write("<parameterList>");
        compileParameterList();
        writer.newLine();
        writer.write("</parameterList>");
        writeOut(eatSymbol(")"));
        writer.newLine();
        writer.write("<subroutineBody>");
        compileSubroutineBody();
        writer.newLine();
        writer.write("</subroutineBody>");
    }

    public void compileParameterList() throws IOException {
        boolean firstTime = true;
        while (tokenizer.hasMoreTokens() && !(tokenizer.getFutureToken().tokenType().equals(TokenType.SYMBOL) && tokenizer.getFutureToken().symbol() == ')')) {
            if (!firstTime) {
                writeOut(eatSymbol(","));
            }
            eatType(asList(KeyWordType.BOOLEAN, KeyWordType.INT, KeyWordType.CHAR));
            String varName = eatIdentifier();
            writeOut(varName);
            firstTime = false;
        }
    }

    public void compileSubroutineBody() throws IOException {
        writeOut(eatSymbol("{"));
        while (tokenizer.hasMoreTokens() && (tokenizer.getFutureToken().tokenType().equals(TokenType.KEYWORD) && tokenizer.getFutureToken().keyWord().equals(KeyWordType.VAR))) {
            compileVarDec();
        }
        compileStatements();
        writeOut(eatSymbol("}"));
    }

    public void compileVarDec() throws IOException {
        writer.newLine();
        writer.write("<varDec>");
        writeOut(eatKeyWord(KeyWordType.VAR));
        compileTypeWithoutVar();
        writer.newLine();
        writer.write("</varDec>");
    }

    public void compileStatements() throws IOException {
        writer.newLine();
        writer.write("<statements>");
        while (tokenizer.hasMoreTokens() && !(tokenizer.getFutureToken().tokenType().equals(TokenType.SYMBOL) && tokenizer.getFutureToken().symbol() == '}')) {
            compileStatement();
        }
        writer.newLine();
        writer.write("</statements>");
    }

    private void compileStatement() throws IOException {
        if (!tokenizer.hasMoreTokens()) {
            throw new IllegalArgumentException("Was expecting a statement.");
        }
        Token futureToken = tokenizer.getFutureToken();
        if (futureToken.tokenType() != TokenType.KEYWORD) {
            throw new IllegalArgumentException("Was expecting a keyword.");
        }
        if (KeyWordType.LET == futureToken.keyWord())
            compileLet();
        else if (KeyWordType.IF == futureToken.keyWord())
            compileIf();
        else if (KeyWordType.WHILE == futureToken.keyWord())
            compileWhile();
        else if (KeyWordType.DO == futureToken.keyWord())
            compileDo();
        else if (KeyWordType.RETURN == futureToken.keyWord())
            compileReturn();
    }

    public void compileLet() throws IOException {
        writer.newLine();
        writer.write("<letStatement>");
        writeOut(eatKeyWord(KeyWordType.LET));
        String varName = eatIdentifier();
        writeOut(varName);
        Token futureToken = tokenizer.getFutureToken();
        if (futureToken.tokenType() != TokenType.SYMBOL)
            throw new IllegalArgumentException("AAAAAAAAAAAAAAAAAAAAAA");
        if (futureToken.symbol() == '[') {
            writeOut(eatSymbol("["));
            compileExpression();
            writeOut(eatSymbol("]"));
        }
        writeOut(eatSymbol("="));
        compileExpression();
        writeOut(eatSymbol(";"));
        writer.newLine();
        writer.write("</letStatement>");
    }

    public void compileIf() throws IOException {
        writer.newLine();
        writer.write("<ifStatement>");
        writeOut(eatKeyWord(KeyWordType.IF));
        writeOut(eatSymbol("("));
        compileExpression();
        writeOut(eatSymbol(")"));
        writeOut(eatSymbol("{"));
        compileStatements();
        writeOut(eatSymbol("}"));
        Token futureToken = tokenizer.getFutureToken();
        if (futureToken.tokenType() == TokenType.KEYWORD && futureToken.keyWord() == KeyWordType.ELSE) {
            writeOut(eatKeyWord(KeyWordType.ELSE));
            writeOut(eatSymbol("{"));
            compileStatements();
            writeOut(eatSymbol("}"));
        }
        writer.newLine();
        writer.write("</ifStatement>");
    }

    public void compileWhile() throws IOException {
        writer.newLine();
        writer.write("<whileStatement>");
        writeOut(eatKeyWord(KeyWordType.WHILE));
        writeOut(eatSymbol("("));
        compileExpression();
        writeOut(eatSymbol(")"));
        writeOut(eatSymbol("{"));
        compileStatements();
        writeOut(eatSymbol("}"));
        writer.newLine();
        writer.write("</whileStatement>");
    }

    public void compileDo() throws IOException {
        writer.newLine();
        writer.write("<doStatement>");
        writeOut(eatKeyWord(KeyWordType.DO));
        compileSubroutineCall();
        writeOut(eatSymbol(";"));
        writer.newLine();
        writer.write("</doStatement>");
    }

    private void compileSubroutineCall() throws IOException {
        String name = eatIdentifier();
        writeOut(name);
        Character symbol = eatSymbol(asList('.', '('));
        writeOut(symbol);
        if ('.' == symbol) {
            String otherName = eatIdentifier();
            writeOut(otherName);
            writeOut(eatSymbol("("));
            compileExpressionList();
            writeOut(eatSymbol(")"));
        } else {
            compileExpressionList();
            writeOut(eatSymbol(")"));
        }
    }

    public void compileReturn() throws IOException {
        writer.newLine();
        writer.write("<returnStatement>");
        KeyWordType keyReturn = eatKeyWord(KeyWordType.RETURN);
        writeOut(keyReturn);
        if (!(tokenizer.getFutureToken().tokenType() == TokenType.SYMBOL && tokenizer.getFutureToken().symbol() == ';')) {
            compileExpression();
        }
        writeOut(eatSymbol(";"));
        writer.newLine();
        writer.write("</returnStatement>");
    }

    public void compileExpression() throws IOException {
        writer.newLine();
        writer.write("<expression>");
        compileTerm();
        List<Character> op = Arrays.asList('a', '+', '-', '=', '/', '*', '&', '|', '<', '>');
        if (tokenizer.getFutureToken().tokenType().equals(TokenType.SYMBOL) && op.contains(tokenizer.getFutureToken().symbol())) {
            Character operation = eatSymbol(op);
            writeOut(operation);
            compileTerm();
        }
        writer.newLine();
        writer.write("</expression>");
    }

    public void compileTerm() throws IOException {
        writer.newLine();
        writer.write("<term>");
        Token futureToken = tokenizer.getFutureToken();
        Token futureFutureToken = tokenizer.getFutureFutureToken();
        if (futureToken.tokenType().equals(TokenType.INT_CONST)) {
            tokenizer.advance();
            int intVal = tokenizer.getCurrentToken().intVal();
            writeOutIntConstant(intVal);
        } else if (futureToken.tokenType().equals(TokenType.STRING_CONST)) {
            tokenizer.advance();
            String strVal = tokenizer.getCurrentToken().stringVal();
            writeOutStringConstant(strVal);
        } else if (futureToken.tokenType().equals(TokenType.KEYWORD) && KEY_WORD_CONSTANT.contains(futureToken.keyWord())) {
            writeOut(eatKeyWord(KEY_WORD_CONSTANT));
        } else if (futureToken.tokenType().equals(TokenType.SYMBOL) && futureToken.symbol() == '(') {
            writeOut(eatSymbol("("));
            compileExpression();
            writeOut(eatSymbol(")"));
        } else if (futureToken.tokenType().equals(TokenType.SYMBOL) && UNARY_OPS.contains(futureToken.symbol())) {
            Character unaryOp = eatSymbol(UNARY_OPS);
            writeOut(unaryOp);
            compileTerm();
        } else if (futureFutureToken != null && futureFutureToken.tokenType().equals(TokenType.SYMBOL) && TERM_LOOKAHEAD.contains(futureFutureToken.symbol())) {
            if ('[' == futureFutureToken.symbol()) {
                String varName = eatIdentifier();
                writeOut(varName);
                writeOut(eatSymbol("["));
                compileExpression();
                writeOut(eatSymbol("]"));
            } else {
                compileSubroutineCall();
            }
        } else {
            String varName = eatIdentifier();
            writeOut(varName);
        }
        writer.newLine();
        writer.write("</term>");
    }

    private void writeOutStringConstant(String strVal) throws IOException {
        writer.newLine();
        writer.write("<stringConstant> " + strVal + " </stringConstant>");
    }

    public void compileExpressionList() throws IOException {
        writer.newLine();
        writer.write("<expressionList>");
        Token futureToken = tokenizer.getFutureToken();
        if (futureToken.tokenType().equals(TokenType.SYMBOL) && futureToken.symbol() == ')') {
            writer.newLine();
            writer.write("</expressionList>");
            return;
        }
        compileExpression();
        while (tokenizer.getFutureToken().tokenType().equals(TokenType.SYMBOL) && tokenizer.getFutureToken().symbol() == ',') {
            writeOut(eatSymbol(","));
            compileExpression();
        }
        writer.newLine();
        writer.write("</expressionList>");
    }

    @Override
    public void close() throws IOException {
        if (writer != null)
            writer.close();
    }
}
